#!/bin/bash
set -euo pipefail
export SLURM_CONF=/etc/slurm/slurm.conf
cd /insomnia001/depts/edu/users/yc4953/projects/allm-dgsc
source scripts/activate_allm.sh
export XLA_PYTHON_CLIENT_MEM_FRACTION=.95
export JAX_COMPILATION_CACHE_DIR=/insomnia001/depts/edu/users/yc4953/hf_cache/jax_sc_test256
log=/insomnia001/depts/edu/users/yc4953/logs/allm-sc-debug-${SLURM_JOB_ID}.log
exec > >(tee --output-error=warn -a "$log") 2>&1
nvidia-smi
if python -u -m exp_code.semantic_intervention.research_block --output "outputs/sc-debug-session-${SLURM_JOB_ID}" --recipe configs/next_research_recipe.txt; then
  echo 'Explicit console exit.'
else
  echo 'Worker failure: allocation retained in recovery shell; do not exit while repair is pending.'
  exec /bin/bash --noprofile --norc -i
fi
