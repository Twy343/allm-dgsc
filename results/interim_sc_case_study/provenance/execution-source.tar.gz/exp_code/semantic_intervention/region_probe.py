"""Matched region templates; report accepted content, not just slot movement."""
import json
from pathlib import Path
import numpy as np
from exp_code.common.acceptance_trace import write_csv


def accepted_occurrences(canvas,mask,template):
  n=len(template)
  return [i for i in range(len(canvas)-n+1)
          if np.array_equal(canvas[i:i+n],template) and bool(np.all(mask[i:i+n]))]


def explore_region(engine,*,focus,case_id,seed,tokenizer,output):
  output=Path(output);output.mkdir(parents=True,exist_ok=False)
  source=tokenizer.encode('4 \\div 2 = 2')
  target=tokenizer.encode('8 \\div 2 = 4')
  reference=engine.reference_canvas_tokens[focus]
  starts=[i for i in range(len(reference)-len(source)+1)
          if np.array_equal(reference[i:i+len(source)],source)]
  if len(source)!=len(target) or len(starts)!=1:
    report=dict(status='selection_blocked',reason='Region template not uniquely aligned or token lengths differ',
        source_token_ids=source,target_token_ids=target,starts=starts)
    (output/'region_plan.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    return report
  start=starts[0]
  plan=dict(status='planned',case_id=case_id,break_after_step=engine.state.step,
      start=start,length=len(source),source_text='4 / 2 = 2',target_text='8 / 2 = 4',
      source_token_ids=source,target_token_ids=target,alpha=1.,
      controls='same region and one-hot entropy: original, coherent counterfactual, repeated unrelated token',
      limit='Prompt still says Ben has4 blue tubes; target is a counterfactual, not correct task reasoning')
  (output/'region_plan.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8')
  rows=[]
  try:
    for name,template in (('original_region',source),('counterfactual_region',target),
                          ('unrelated_region',[529]*len(source))):
      engine.restore('committed')
      edit=engine.region(start=start,tokens=template,alpha=1.,batch=focus)
      for horizon in range(1,6):
        if engine.finished or bool(engine.state.done[focus]):break
        engine.step()
        canvas=np.asarray(engine.state.canvas[focus])
        mask=engine.recorder.events[-1]['accepted'][focus]
        found=accepted_occurrences(canvas,mask,target)
        rows.append(dict(case_id=case_id,condition=name,horizon=horizon,
            step_number=engine.state.step,original_region_start=start,
            accepted_counterfactual_exact_any_position=bool(found),
            counterfactual_positions=json.dumps(found),
            accepted_original_exact_any_position=bool(accepted_occurrences(canvas,mask,source)),
            decoded_region=tokenizer.decode(canvas[start:start+len(source)].tolist()),
            region_accepted_count=int(mask[start:start+len(source)].sum()),
            note='Exact accepted token-template match; a negative does not rule out paraphrases'))
        print('REGION_PROBE_STEP',name,'+',horizon,'accepted_counterfactual_spans',found,flush=True)
      folder=output/name
      summary=engine.recorder.export(folder,focus,case_id,seed,tokenizer)
      summary.update(edits=engine.edits,region_edit=edit,partial=True)
      (folder/'branch.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
      write_csv(output/'region_observations.csv',rows)
    report=dict(status='region_probe_complete',
        counterfactual_accepted_in_counterfactual_branch=any(r['accepted_counterfactual_exact_any_position']
            for r in rows if r['condition']=='counterfactual_region'),
        exact_match_scope='<=5 active steps, scan all canvas positions and require acceptance of every token',
        hypothesis='Region intervention may transmit coherent candidate content more effectively than one-row swap')
    (output/'region_result.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    return report
  finally:
    engine.restore('committed')
