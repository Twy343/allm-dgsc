"""CPU grading after GPU exits; raw traces and generations remain unchanged."""
import json
from pathlib import Path
from exp_code.baselines.offline_score import clean_code
from exp_code.baselines.scoring import score_gsm8k,score_mbpp
from exp_code.baselines.run import write_json


def main():
  output=Path('outputs/full-sc-steptrace-v1')
  config=json.loads((output/'run.json').read_text())['config']
  baseline=json.loads((Path(config['baseline_output'])/'run.json').read_text())
  cases={(task,c['id']):c for task,plan in baseline['plans'].items() for c in plan['cases']}
  rows=[]
  def grade(row,condition):
    task=row['task'];case=cases[task,row['case_id']]
    if task=='gsm8k':score=score_gsm8k(row['generated_text'],case['reference'])
    else:score=score_mbpp(clean_code(row['generated_text']),case['tests'],case.get('test_imports',()),timeout=10)
    rows.append(dict(case_id=row['case_id'],task=task,condition=condition,
        passed=score['passed'],score_status=score['status'],
        actual_total_steps=row['actual_total_steps'],steps_per_canvas=row['steps_per_canvas'],
        generated_text=row['generated_text'],score_details=json.dumps(score)))
  for row in json.loads((output/'samples.json').read_text()):grade(row,'full_unmodified')
  for file in sorted((output/'semantic_pilot').glob('*/*/sample.json')):
    row=json.loads(file.read_text());grade(row,row['condition'])
  destination=output/'cpu_scores';destination.mkdir(exist_ok=True)
  import csv
  with (destination/'scores.csv').open('w',encoding='utf-8-sig',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
  write_json(destination/'scores.json',rows)
  (output/'CPU_SCORING_COMPLETE').touch()
  print('TRACE_CPU_SCORING_COMPLETE',len(rows),flush=True)


if __name__=='__main__':main()
