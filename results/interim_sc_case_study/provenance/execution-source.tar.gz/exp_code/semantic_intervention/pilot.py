"""Two prespecified semantic examples; matched batch/seed, original canvas fixed.

Only the unmodified trajectory determines the target and intervention timing.
The pilot does not automatically expand to 30 interventions.
"""
import dataclasses
import gc
import json
from pathlib import Path
import re
import time


def choose_site(summary,trace_output,tokenizer):
  import numpy as np
  ids=json.loads(summary['output_tokens'])
  # These contexts fix the intended meaning, rather than swapping an arbitrary
  # occurrence of a digit or a comparison in echoed test assertions.
  if summary['case_id']=='mbpp:277':
    source_text='>=';target_text='<'
    predicate=lambda left,right: bool(re.search(r'if\s+v\s*$',left) and re.match(r'\s*n\b',right))
    meaning='dict_filter: keep v >= n -> keep v < n'
  elif summary['case_id']=='gsm8k:480':
    source_text='2';target_text='4'
    predicate=lambda left,right: bool(re.search(r'4\s*(?:\\div|/)\s*2\s*=\s*$',left))
    meaning='Jasper blue paint intermediate: 4 / 2 = 2 -> 4 / 2 = 4'
  else:raise ValueError('Case not prespecified')
  positions=[]
  for position,token in enumerate(ids):
    if tokenizer.decode([token]).strip()!=source_text:continue
    left=tokenizer.decode(ids[max(0,position-24):position])
    right=tokenizer.decode(ids[position+1:position+13])
    if predicate(left,right):positions.append((position,left,right))
  if len(positions)!=1:
    raise ValueError(f'Expected one verified semantic site; found {len(positions)}')
  absolute,left,right=positions[0];source=ids[absolute]
  prefix=re.match(r'\s*',tokenizer.decode([source])).group()
  choices=[tokenizer.encode(text) for text in (prefix+target_text,target_text)]
  choices=[ids for ids in choices if len(ids)==1 and tokenizer.decode(ids).strip()==target_text]
  if not choices:
    raise ValueError('Counterfactual is not an exact one-token replacement')
  target_ids=choices[0]
  target=int(target_ids[0])
  if target==source:raise ValueError('Identical source and target')
  archive=np.load(trace_output/(summary['case_id'].replace(':','-')+'.npz'))
  canvas,pos=divmod(absolute,256)
  indices=np.flatnonzero(archive['canvas_indices']==canvas)
  # Earliest confidently expressed source, with a subsequent normal step.
  eligible=[]
  for index in indices[:-1]:
    top_ids=archive['top_ids'][index,pos];probs=archive['top_probs'][index,pos]
    if int(top_ids[0])==source and float(probs[0])>=.5:eligible.append(int(index))
  if not eligible:raise ValueError('No confident source with a subsequent step')
  event_index=eligible[0];step=int(archive['step_indices'][event_index])
  # Recover exact model position from the exported CSV, including prompt offset.
  import csv
  name=summary['case_id'].replace(':','-')
  with (trace_output/f'{name}_tokens.csv').open(encoding='utf-8-sig',newline='') as f:
    row=next(r for r in csv.DictReader(f) if int(r['canvas_index'])==canvas
             and int(r['step_index'])==step and int(r['canvas_position'])==pos)
  offset=int(row['model_position'])-pos
  return dict(case_id=summary['case_id'],meaning=meaning,canvas_index=canvas,
      position=pos,response_position=absolute,model_canvas_offset=offset,
      intervention_step_index=step,intervention_step_number=step+1,
      first_affected_step_index=step+1,source_token_id=int(source),target_token_id=target,
      source_token=tokenizer.decode([source]),target_token=tokenizer.decode([target]),
      baseline_accepted_at_t=bool(archive['accepted'][event_index,pos]),
      context_before=left,context_after=right,
      timing_rule='earliest top-1 source probability >= .5 with a subsequent baseline step')


def run_pilot(*,loaded,base,trace_output,previous):
  import dialog
  import jax
  import numpy as np
  from exp_code.common.acceptance_trace import AcceptanceRecorder,TracedPredictions,write_csv
  from exp_code.common.trace_sc_sampler import ObservedSampler
  from exp_code.baselines.run import write_json
  model,params,tokenizer,sharding=loaded
  output=trace_output/'semantic_pilot';output.mkdir(exist_ok=True)
  original=json.loads((trace_output/'samples.json').read_text())
  by_id={r['case_id']:r for r in original}
  watched=tuple(json.loads((trace_output/'watched_tokens.json').read_text())['token_ids'])
  end_tokens=base._initialize_sampler_loop(base.sampling).end_tokens
  findings=[]
  for case_id in ('mbpp:277','gsm8k:480'):
    folder=output/case_id.replace(':','-');folder.mkdir(exist_ok=True)
    if (folder/'PILOT_COMPLETE').exists():continue
    summary=by_id[case_id]
    try:site=choose_site(summary,trace_output,tokenizer)
    except ValueError as error:
      write_json(folder/'selection_blocked.json',dict(case_id=case_id,error=str(error)))
      print('SEMANTIC_SITE_NOT_ELIGIBLE',case_id,str(error),flush=True)
      continue
    write_json(folder/'intervention.json',site)
    task=summary['task'];start=summary['batch_index']*4
    cases=previous['plans'][task]['cases'][start:start+4];batch=summary['batch_position']
    prompts=[dialog.Conversation(dialog.User(c['prompt'])).as_text(format=tokenizer.FORMAT) for c in cases]
    source=site['source_token_id'];target=site['target_token_id'];random_target=None
    control_ids=[]
    for token in range(tokenizer.vocab_size):
      if token in (source,target):continue
      if tokenizer.decode([token]).strip().isalpha():control_ids.append(token)
    control_ids=np.array(control_ids,dtype=np.int32)
    for condition in ('noop','semantic_swap','matched_random_swap'):
      destination=folder/condition;destination.mkdir(exist_ok=True)
      recorder=AcceptanceRecorder(len(cases),end_tokens,progress_label=f'{case_id}/{condition}')
      full_rows=[]
      def row_callback(step,offset,row,active):
        full_rows.append(dict(step=int(step),offset=int(offset),
                              logits=np.array(row,copy=True),active=bool(active)))
      if condition=='matched_random_swap' and random_target is None:
        raise ValueError('Random control selection missing')
      actual_target=random_target if condition=='matched_random_swap' else target
      spec=(site['intervention_step_index'],batch,site['model_canvas_offset'],
          site['position'],source,actual_target,condition!='noop')
      sampler=ObservedSampler(**{f.name:getattr(base,f.name) for f in dataclasses.fields(base) if f.init},
          context_callback=recorder.record_context,swap=spec,row_callback=row_callback)
      sampler=dataclasses.replace(sampler,sample_from_predictions=TracedPredictions(
          callback=recorder.record,early_stop_fn=base.early_stop_fn,
          text_vocab_size=tokenizer.vocab_size,top_k=16,watched_token_ids=watched))
      print('SEMANTIC_PILOT_GENERATION_START',case_id,condition,site,flush=True)
      begin=time.perf_counter()
      result=sampler.sample(prompts,rng=summary['seed'],max_new_tokens=previous['max_new_tokens'],
                            return_state=True,sharding=sharding)
      jax.block_until_ready(result.tokens);jax.effects_barrier()
      tokens=np.array(result.tokens,copy=True);text=list(result.text)[batch]
      del result;gc.collect()
      traced_summary=recorder.export(destination,batch,case_id,summary['seed'],tokenizer)
      traced_summary.update(task=task,condition=condition,generated_text=text,
          output_tokens=json.dumps(tokens[batch].tolist()),
          generation_seconds=time.perf_counter()-begin,score_status='pending_cpu')
      write_json(destination/'sample.json',traced_summary)
      write_csv(destination/'sample.csv',[traced_summary])
      active_steps={e['step'] for e in recorder.events if e['active'][batch]
          and int(e['position_offsets'][batch])==site['model_canvas_offset']}
      relevant=[r for r in full_rows if r['offset']==site['model_canvas_offset']
          and r['step'] in active_steps]
      np.savez_compressed(destination/'full_target_row_logits.npz',
          logits=np.stack([r['logits'] for r in relevant]),
          step_indices=np.array([r['step'] for r in relevant]),
          intervention_active=np.array([r['active'] for r in relevant]),
          note=np.array('Pre-intervention temperature-shaped logits, full vocabulary at the target position'))
      intervention_rows=[r for r in relevant if r['step']==site['intervention_step_index']]
      if len(intervention_rows)!=1:raise ValueError('Intervention step missing or ambiguous')
      at_t=intervention_rows[0]['logits']
      if not np.isfinite(at_t[[source,actual_target]]).all():
        raise ValueError('Selected logit is forbidden/nonfinite')
      event=next(e for e in recorder.events if e['step']==site['intervention_step_index']
                 and int(e['position_offsets'][batch])==site['model_canvas_offset'])
      baseline_archive=np.load(trace_output/(case_id.replace(':','-')+'.npz'))
      t_index=np.flatnonzero((baseline_archive['canvas_indices']==site['canvas_index']) &
                            (baseline_archive['step_indices']==site['intervention_step_index']))[0]
      # At intervention time SC changes only; all samples up to and including
      # this step must remain identical to the unmodified trace.
      for e in recorder.events:
        offset=int(e['position_offsets'][batch])
        if offset>site['model_canvas_offset']:continue
        if offset==site['model_canvas_offset'] and e['step']>site['intervention_step_index']:continue
        if not e['active'][batch]:continue
        matches=np.flatnonzero((baseline_archive['canvas_indices']==
            (offset-site['model_canvas_offset'])//256+site['canvas_index']) &
            (baseline_archive['step_indices']==e['step']))
        if len(matches)!=1:raise ValueError('Baseline prefix matching failed')
        np.testing.assert_array_equal(e['after'][batch],baseline_archive['after'][matches[0]])
      if condition=='noop':
        if text!=summary['generated_text']:raise AssertionError('No-op text identity failed')
        payload=np.load(destination/(case_id.replace(':','-')+'.npz'))
        for key in ('before','sampled','accepted','after'):
          np.testing.assert_array_equal(payload[key],baseline_archive[key])
        finite=control_ids[np.isfinite(at_t[control_ids])]
        random_target=int(finite[np.argmin(np.abs(at_t[finite]-at_t[target]))])
        site.update(random_target_id=random_target,random_target_token=tokenizer.decode([random_target]),
            random_target_logit_difference=float(abs(at_t[random_target]-at_t[target])))
        write_json(folder/'intervention.json',site)
      before_source=float(at_t[source]);before_target=float(at_t[actual_target])
      edits=[dict(case_id=case_id,condition=condition,
          canvas_index=site['canvas_index'],step_index=site['intervention_step_index'],
          step_number=site['intervention_step_number'],canvas_position=site['position'],
          token_id=token,token=tokenizer.decode([token]),logit_before=before,
          logit_after=after,applied=condition!='noop')
          for token,before,after in ((source,before_source,before_target),(actual_target,before_target,before_source))]
      if condition=='noop':
        for edit in edits:edit['logit_after']=edit['logit_before']
      write_csv(destination/'logit_edits.csv',edits)
      # Paired next-step and later changes, including all downstream positions.
      changed=[]
      for e in recorder.events:
        if not e['active'][batch]:continue
        current_canvas=(int(e['position_offsets'][batch])-site['model_canvas_offset'])//256+site['canvas_index']
        matches=np.flatnonzero((baseline_archive['canvas_indices']==current_canvas)&
                              (baseline_archive['step_indices']==e['step']))
        if len(matches)!=1:continue  # Different stopping lengths are reported separately.
        ref=int(matches[0])
        for pos in range(256):
          changed.append(dict(case_id=case_id,condition=condition,canvas_index=current_canvas,
              step_index=e['step'],step_number=e['step']+1,position=pos,
              is_target=pos==site['position'] and current_canvas==site['canvas_index'],
              baseline_accepted=bool(baseline_archive['accepted'][ref,pos]),
              intervention_accepted=bool(e['accepted'][batch,pos]),
              baseline_token_id=int(baseline_archive['after'][ref,pos]),
              intervention_token_id=int(e['after'][batch,pos]),
              baseline_entropy=float(baseline_archive['entropy'][ref,pos]),
              intervention_entropy=float(e['entropy'][batch,pos])))
      write_csv(destination/'paired_positions.csv',changed)
      print('SEMANTIC_PILOT_COMPLETE',case_id,condition,'steps',traced_summary['actual_total_steps'],flush=True)
      del recorder,sampler,full_rows;gc.collect()
    (folder/'PILOT_COMPLETE').touch()
    findings.append(site)
  write_json(output/'pilot_sites.json',findings)
  (output/'PILOT_STAGE_FINISHED').touch()
  print('SEMANTIC_PILOT_STAGE_FINISHED',len(findings),'cases; no automatic expansion',flush=True)
