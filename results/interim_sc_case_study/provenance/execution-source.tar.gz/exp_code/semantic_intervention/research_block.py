"""One resident two-hour research block: validate once, execute recipe, stay open."""
import argparse
import json
from pathlib import Path
import sys
import jax
from exp_code.baselines.model_loading import load_model
from exp_code.baselines.run import source_identity
from exp_code.common.sc_sampler import SCSampler
from exp_code.semantic_intervention.debug_console import Console,resident_checkpoint_gate


def main():
  parser=argparse.ArgumentParser(description=__doc__)
  parser.add_argument('--output',type=Path,required=True)
  parser.add_argument('--recipe',type=Path,required=True)
  args=parser.parse_args();args.output.mkdir(parents=True,exist_ok=False)
  previous=json.loads(Path('outputs/sc-benchmark64-deferred-v2/run.json').read_text())
  (args.output/'session.json').write_text(json.dumps(dict(
      checkpoint_sha256=previous['checkpoint_sha256'],source_sha256=source_identity(),
      device_kind=[d.device_kind for d in jax.devices()],python=sys.version,jax=jax.__version__,
      recipe=args.recipe.read_text(),idle_seconds=0),indent=2)+'\n',encoding='utf-8')
  print('SINGLE_WEIGHT_LOAD_START',flush=True)
  model,params,tokenizer,_=load_model(Path(previous['checkpoint']),1)
  chat=SCSampler(model=model,params=params,tokenizer=tokenizer,
      cache_length=previous['cache_length'],max_out_length=previous['max_new_tokens'],
      canvas_length=256,max_denoising_steps=48)
  console=Console(chat,previous,args.output,idle_seconds=0)
  console.engine,console.initial,console.focus,console.seed=resident_checkpoint_gate(chat,previous,args.output)
  console.case_id='gsm8k:480'
  for line in args.recipe.read_text().splitlines():
    if not line.strip() or line.lstrip().startswith('#'):continue
    print('RESEARCH_COMMAND',line,flush=True)
    console.precmd(line)
    if console.onecmd(line):break
  while True:
    try:console.cmdloop();break
    except (Exception,KeyboardInterrupt):console.recover_command_error('research console input loop')


if __name__=='__main__':main()
